#include <stdio.h>

int main()
{
    float sum = 0.00;
    printf("The integers are :\n");

    for(int i=9; i<=300; i++){
        if(i%7==0 && i%63!=0){
            printf("%d\n",i);
            sum=sum+i;
        }
        else{
            sum=sum;
        }
    }
    printf("The sum is : %f",sum);
    return 0;
}
