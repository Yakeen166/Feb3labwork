#include <stdio.h>
#include <math.h>

int main()
{
    float northktm, eastktm, northpkr, eastpkr;

    printf("Enter North of ktm: ");
    scanf("%f", &northktm);
    printf("Enter East of ktm: ");
    scanf("%f", &eastktm);


    printf("Enter North of pkr: ");
    scanf("%f", &northpkr);
    printf("Enter East of pkr: ");
    scanf("%f", &eastpkr);

    float distance = ((northktm-northpkr)*(northktm-northpkr))+((eastktm-eastpkr)*(eastktm-eastpkr));

    printf("The distance is %f\n", sqrt(distance));

}
