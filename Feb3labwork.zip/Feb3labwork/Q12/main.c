#include <stdio.h>

int main()
{
    int i = 1, num, totalno = 0, maxm = 86000, minm= -86000, sum=0;
    float average = 0.0;


    printf("Enter the numbers:\n");
    do{
        scanf("%d", &num);
        if(num == 0 || num < 0){
            break;
        }

        if(num < maxm){
            minm = num;
            if(maxm == 86000){
                maxm = minm;
            }
        }

        if(num > minm){
            maxm = num;
        }

        //printf("%d", num);

        totalno++;
        sum += num;
        average = sum/totalno;
    }while(i);

        printf("Sum is: %d, average is: %f, maximum is: %d, minimum is: %d\n", sum, average, maxm, minm);
}
